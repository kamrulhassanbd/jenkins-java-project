#! /bin/bash
/opt/tomcat8/bin/shutdown.sh

demo
